import RunInput.Run;

public class Main {
    public static void main(String[] args) {
        Run run = new Run();
        run.RunTask();
    }
}