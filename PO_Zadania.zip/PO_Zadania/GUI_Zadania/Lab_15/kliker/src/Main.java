public class Main {
    public static void main(String[] args) {
        Kliker kliker = new Kliker();
        kliker.setVisible(true);
    }
}