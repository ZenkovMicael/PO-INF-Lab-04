public class Main {
    public static void main(String[] args) {
        Konwerter konwerter = new Konwerter();
        konwerter.setVisible(true);
    }
}