//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        WelcomeForm welcomeForm = new WelcomeForm();
        //RadioBtnExample radioBtnExample = new RadioBtnExample();
        //radioBtnExample.setVisible(true);
        //CheckBoxExample checkBoxExample = new CheckBoxExample();
        //checkBoxExample.setVisible(true);
        //ComboBox comboBox = new ComboBox();
        //comboBox.setVisible(true);
    }
}