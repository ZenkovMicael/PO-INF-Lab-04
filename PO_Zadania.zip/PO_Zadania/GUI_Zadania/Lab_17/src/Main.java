import Forms.ContactsForm;

public class Main {
    public static void main(String[] args) {
        ContactsForm contactsForm = new ContactsForm();
        contactsForm.setVisible(true);
    }
}