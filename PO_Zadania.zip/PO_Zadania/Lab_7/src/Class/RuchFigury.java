package Class;

public interface RuchFigury {
    void przesun(float x, float y);
}
