package Class;

public interface Elektryczny {
    void naladuj();
    int poziomNaladowania();
}
