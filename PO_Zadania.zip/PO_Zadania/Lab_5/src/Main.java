import RunInput.Run;
import Class.*;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Run run = new Run();
        run.RunTask();
    }
}