package Class;

public class Adres {
    public String ulica;
    public int nrDomu, nrMieszkania;
    public String miasto, kodposcztowy;


}
