package Task;

public class BlednaWartoscDlaSilniException extends Exception{
    public BlednaWartoscDlaSilniException(String komunikat){
        super(komunikat);
    }
}
