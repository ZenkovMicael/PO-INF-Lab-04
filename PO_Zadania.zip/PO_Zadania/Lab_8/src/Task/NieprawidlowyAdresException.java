package Task;

public class NieprawidlowyAdresException extends Exception{
    public NieprawidlowyAdresException(String message) {
        super(message);
    }
}
